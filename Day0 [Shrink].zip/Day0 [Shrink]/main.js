let canvas = document.querySelector("canvas");

function button(){
    //change the color of the canvas
    canvas.style = "background-color: purple;";
    

    //shrink the width an height of the convas by 10%
    canvas.width -= canvas.width*(10/100);
    canvas.height -= canvas.height*(10/100);
    
    if(canvas.width == 0){
        alert("width is now 0!");
    }

    if(canvas.height == 0){
        alert("height is now 0!");
    }
    
    
    //alert("new Width: "+ canvas.width);
    //alert("new Height: "+ canvas.height);

    //log the height and width values on a console to monitor them
    console.log("Height: ",canvas.height);
    console.log("Width: ",canvas.width)

}