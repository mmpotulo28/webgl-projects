//set reference to color
let canvas = document.querySelector('canvas')
//get a webgl context
let context = canvas.getContext('webgl')
//2 set canvas color
context.clearColor(1.0, 1.0, 0, 1)
context.clear(context.COLOR_BUFFER_BIT)

//3 Specify vertex data
const verticies = new Float32Array([0, 0, -1, -1, -1, 0])

//4 create buffers for position, color. or combined
const buffer = context.createBuffer()

//5 bind the buffer as the current buffer
context.bindBuffer(context.ARRAY_BUFFER, verticies, context.STATIC_DRAW)

//6. Specify that buffer data from vertex data
context.bufferData(context.ARRAY_BUFFER, verticies, context.STATIC_DRAW)

//7. Create the two shaders source
const vsSource = `attribute vec2 pos;
void main() { gl_Position = vec4(pos,0,1); }`

const fsSource = `
 void main() { gl_FragColor = vec4(1.0,0,0,1.0); }`

//8. Create Javascript reference to the shaders
const vertexShader = webgl.createShader(webgl.VERTEX_SHADER)
const fragmentShader = webgl.createShader(webgl.FRAGMENT_SHADER)

//9. Pass the shader sources to the shader reference
webgl.shaderSource(vertexShader, vsSource)

webgl.shaderSource(fragmentShader, fsSource)

//10. Compile the shaders
webgl.compileShader(vertexShader)
webgl.compileShader(fragmentShader)

//11. Create a program, attach shaders and link program
const program = webgl.createProgram()
webgl.attachShader(program, vertexShader)
webgl.attachShader(program, fragmentShader)
webgl.linkProgram(program)

//12. Find a reference to each of the attributes in the shader
const positionLocation = webgl.getAttribLocation(program, `pos`)

//13.Enable the attribute, it is disabled by default
webgl.enableVertexAttribArray(positionLocation)

//14. Specify the layout of the vertex data
webgl.vertexAttribPointer(index, size, type, normalized, stride, offset)
webgl.vertexAttribPointer(positionLocation, 2, webgl.FLOAT, false, 0, 0)

//15. specify which program you are using
webgl.useProgram(program)

//16. finally draw the primitives i.e triangles/lines
webgl.drawArrays(webgl.TRIANGLES, 0, 3)
