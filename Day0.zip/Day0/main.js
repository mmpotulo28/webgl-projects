let canvas = document.querySelector("canvas");
let button = document.querySelector("button");
let canv = document.getElementById("mycanv");

button.onclick = () =>{

    let st = "background-color: blue";
    canvas.style = st;
}